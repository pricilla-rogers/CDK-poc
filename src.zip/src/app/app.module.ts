import { BrowserModule } from '@angular/platform-browser';
import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
// import { FormModalComponent } from './form-modal/form-modal.component';

import { ModalModule } from '@rogers/cdk/modal';
import { ButtonModule } from '@rogers/cdk/button';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormModule as CoreFormModule } from '@rogers/cdk/form';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { LoginComponent } from './login/login.component';

import { TabsModule } from '@rogers/cdk/tabs';
import { IconModule } from '@rogers/cdk/icon';

import { AuthGuard } from './auth.guard';
import { DashboardComponent } from './dashboard/dashboard.component';
import { PictureModule } from '@rogers/cdk/picture';




@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ModalModule,
    ButtonModule,
    FormsModule,
    BrowserAnimationsModule,
    CoreFormModule,
    ReactiveFormsModule,
    TabsModule,
    IconModule,
    PictureModule
  ],
  providers: [AuthGuard],
  bootstrap: [AppComponent],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class AppModule { }
