import { Component, Input, OnInit, TemplateRef, ViewContainerRef } from '@angular/core';
import { ModalInjectableData } from '@rogers/cdk/common/classes';
import { ModalRef, ModalService } from '@rogers/cdk/modal';
// import { FormModalComponent} from 'src/app/form-modal/form-modal.component';
import { DataService } from '../data.service';
import { Router } from '@angular/router';

import { AfterViewInit, ViewChild } from '@angular/core';
import { TabsComponent } from '@rogers/cdk/tabs';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

import { AuthService } from '../auth.service';
import { CheckboxChange } from '@rogers/cdk/form';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent {

  checkboxModel: boolean = true;
  checkboxControl = new FormControl(false, [Validators.required]);
 @Input() ClassTeacher="Class Teacher"

 @Input() Basicdetails="Basic Details"

 @Input() bgColor="red"

 @Input() MoreDetails="More Details"

 @Input() AboutUs="About Us"

 @Input() decor="none"

 @Input() 
 imgSrc:string="/assets/image.jpeg"
 
//  @Input()
//  altTxt?: string ='Save Earth';

//  @Input()
//  figCaptionTxt?: string=
//  'The average global surface temperature has already increased by more than 1°Cin the last 140 years. In particular, according to the scientific reports of the Intergovernmental Panel on Climate Change (IPCC), the sharp increase in global warming since 1950 can no longer be explained by natural climate fluctuations. According to the sixth IPCC report from 2021, the “extent of the most recent changes in the entire climate system […] are unprecedented in many hundreds to thousands of years".Greenhouse gases such as carbon dioxide (CO2) are responsible for this, which enter the atmosphere through the burning of fossil fuels such as coal, crude oil and natural gas and through large-scale land use, for example, the deforestation of tropical rainforests, and increase the greenhouse effect. '
 
//  @Input()
//  imgOpacity?: number =1;


  @ViewChild(TabsComponent, { static: true }) tabs: TabsComponent;

  title = 'CDK';
  list : any=[];
  // logged:boolean=false;
  currentTab:string;

  modalRef: ModalRef;
  activeIndex: number;

  moreForm: FormGroup;
  userForm: FormGroup;
  morelist: any;

  id: string;
  
  constructor(
    private modalService: ModalService,
    private viewContainerRef: ViewContainerRef,
    private data:DataService,
    private router : Router,
    private fb: FormBuilder,
    private authService: AuthService,
  ) {
    // this.data.content.subscribe( x=> {this.list.push(x);});
    this.setTab("basicdetails");
    this.morelist=[];
    this.list=[];

    this.moreForm=this.fb.group({
      class:['',Validators.required],
      teacher:['',Validators.required],
      schoolname:['',Validators.required],
      comments:['',Validators.required],
    })

    this.userForm=this.fb.group({
      name:['',Validators.required],
      phone:['',Validators.required],
      address:['',Validators.required],
      percentage:['',Validators.required],
    })    
    
    
    
    
   // console.log(this.list);
  }

  ngOnIt(): void {
    this.id=localStorage.getItem('token');
    
  }
  onChange(event: CheckboxChange) {
    console.log('changed: ', event);
  }

   ngAfterViewInit() {
  //   // property "activeIndex" of tabs can be accessed this way
  //   this.activeIndex = this.tabs.activeIndex;
   }

  // login() {
  //   this.data.login.subscribe(res=>{this.logged=res;console.log("res",res);})
  //   this.router.navigate(['/login']);
  // }

  // logout() {
  //   this.logged=false;
  //   console.log(this.logged);
  //   this.router.navigate(['/login']);
  // }

  logout(){
    console.log("logout");
    this.authService.logout();
    this.router.navigate(['/login']);

  }

  remove(element) {
    if(this.currentTab=='moredetails')
    {
      this.morelist.forEach((value,index) => {
        if(value==element){
          this.morelist.splice(index,1);
        }
      });

    }
    else {
      this.list.forEach((value,index) => {
        if(value==element){
          this.list.splice(index,1);
        }
      });

    }
  }

  // openModalWithComponent() {
  //   const data = new ModalInjectableData({ hello: 'world' });
  //   //console.log(this.list);
  //   this.modalRef = this.modalService.open(
  //     FormModalComponent, // see ModalData1Component for more details
  //     this.viewContainerRef,
  //     null,
  //     data,
  //   )
  // }

  openModalWithComponent(templateRef:TemplateRef<any>) {
    this.modalRef=this.modalService.open(
      templateRef,
      this.viewContainerRef,
      null,
    );

  }

  openModal(templateRef: TemplateRef<any>) {
    this.modalRef = this.modalService.open(
      templateRef,
      this.viewContainerRef,
      null,
    );
  }

  reset() {
    if(this.currentTab=='moredetails'){
      this.moreForm.reset();
    }
    else{
      this.userForm.reset();
    }
  }

  setTab(tab: string){
    this.currentTab=tab;
    this.data.updateTab(this.currentTab);


  }

  addItem() :void {
    if(this.currentTab=='moredetails'){
      this.morelist.push(this.moreForm.value);
      console.log(this.morelist);
      this.modalRef.close();
    }
    else{
      this.list.push(this.userForm.value);
      console.log(this.list);
      this.modalRef.close();
    }
  }
}
